#include "stm32l4xx_hal.h"
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
void runMotor(uint8_t left_0_right_1 );
