#include "stm32l4xx_hal.h"

void sendToApp(UART_HandleTypeDef *huart1, float *user_stats);
